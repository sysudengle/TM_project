#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>
#include "freq_list.h"
#include "worker.h"


/* Print to standard output the frequency records for a word.
* Used for testing.
*/
void print_freq_records(FreqRecord *frp) {
	int i = 0;
if (!frp) return;
	while(frp[i].freq != 0) {
		printf("%d    %s\n", frp[i].freq, frp[i].filename);
		i++;
	}
}

void init_freq_records(FreqRecord *frp) {
	int i = 0;
	for(i = 0; i< MAXRECORDS; i++ ) {
		frp[i].freq = 0;
		frp[i].filename[0] = '\0';
	}
}

void insert_freq_record(FreqRecord *frp, FreqRecord newfr) {
	int i = 0;
	int j = 0;
	
	for(i = 0; i < MAXRECORDS; i++) {
		if(frp[i].freq == 0) {
			frp[i] = newfr;
			break;
		} else if(frp[i].freq < newfr.freq) {
			// move everyone else down
			for(j = MAXRECORDS-1; j > i; j--) {
				frp[j] = frp[j-1];
			}
			frp[i] = newfr;
			break;
		}
	}
}



/* Returns an array of frequency records for word in the list head.
*/
FreqRecord *get_word(char *word, Node *head, char **file_names) {
    Node *currNode = head;
	FreqRecord *f = NULL; 
	int i = 0;
	int fr_index = 0;
	f = malloc(MAXFILES * sizeof(FreqRecord));

    // Attempt to find word in the list pointed to by head.
    while((currNode != NULL) && (strcmp(word, currNode->word) > 0)) {
        currNode = currNode->next;
    }

    if((currNode != NULL) && (strcmp(word, currNode->word) == 0)) {
		/* For each file in the list copy a record */
		
		for(i = 0; i < MAXFILES; i++) {
			//fprintf(stderr, "found %s\n", word);
			if(currNode->freq[i] > 0) {
				f[fr_index].freq = currNode->freq[i];
				strncpy(f[fr_index].filename, file_names[i], PATHLENGTH);
				f[fr_index].filename[PATHLENGTH-1] = '\0';
				fr_index++;
			}
		}
	}
	//fprintf(stderr, "[%d] In get_word last index is %d\n", getpid(), fr_index);  
	f[fr_index].freq = 0;
	f[fr_index].filename[0] = '\0';
    
    return f;
}



/* run_worker
* - load the index found in dirname
* - read a word from the file descriptor "in"
* - find the word in the index list
* - write the frequency records to the file descriptor "out"
*/
void run_worker(char *dirname, int in, int out){
	
	printf("Starting worker with %s, %d, %d\n", dirname, in, out);
	char **filenames = init_filenames();
	
	char indexfile[PATHLENGTH];
	strncpy(indexfile, dirname, PATHLENGTH);
	indexfile[PATHLENGTH-1] = '\0';
	strncat(indexfile, "/", PATHLENGTH - strlen(indexfile) -1);
	strncat(indexfile, "index", PATHLENGTH - strlen(indexfile) - 1);
	char namefile[PATHLENGTH];
	strncpy(namefile, dirname, PATHLENGTH);
	namefile[PATHLENGTH-1] = '\0';
	strncat(namefile, "/", PATHLENGTH - strlen(namefile) -1);
	strncat(namefile, "filenames", PATHLENGTH - strlen(namefile)-1);
	
	/* Get the index file into a data structure in memory */
	Node *head;
	read_list(indexfile, namefile, &head, filenames);
	//display_list(head, filenames);

	/* Get each word from the master process */
	char word[MAXWORD + 1];
	int result;
	result = read(in, word, MAXWORD);
	while(result != 0) {
		if(result == -1) {
			perror("read from pipe");
			exit(1);
		}
word[result] = '\0';

		char *ptr;
		if((ptr = strchr(word, '\n'))) {
			*ptr = '\0';
		}
		fprintf(stderr, "[%d] Worker got %s\n", getpid(), word);
		FreqRecord *fr = get_word(word, head, filenames);
		//fprintf(stderr, "[%d] First rec is %d f=%s\n", getpid(), fr[0].freq, fr[0].filename);
		//print_freq_records(fr);
		int i;
		for(i = 0; fr[i].freq > 0; i++) {
			//fprintf(stderr, "[%d] TEST: %d %s\n", getpid(), fr[i].freq, fr[i].filename);
			if(write(out, &fr[i], sizeof(FreqRecord)) != sizeof(FreqRecord)) {
				perror("worker write");
			}
		}
		// and then write the last one
		if(write(out, &fr[i], sizeof(FreqRecord)) != sizeof(FreqRecord)) {
			perror("worker write");
		}
		//fprintf(stderr, "[%d] Last record index %d\n", getpid(), i);
		//print_freq_records(fr);
		
		result = read(in, word, MAXWORD);

	}
}

