#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include "freq_list.h"
#include "worker.h"


int main(int argc, char **argv) {
	
	char ch;
	char path[PATHLENGTH];
	int infds[MAXWORKERS][2];
	int outfds[MAXWORKERS][2];
	int pids[MAXWORKERS];
	int numkids = 0;
	char line[MAXWORD];
	char *startdir = ".";
	
	int i;
	for(i = 0; i < MAXWORKERS; i++){
		infds[i][0] = -1;
		infds[i][1] = -1;
		outfds[i][0] = -1;
		outfds[i][1] = -1;
		pids[i] = -1;
	}

	while((ch = getopt(argc, argv, "d:")) != -1) {
		switch (ch) {
			case 'd':
			startdir = optarg;
			break;
			default:
			fprintf(stderr, "Usage: query [-d DIRECTORY_NAME]\n");
			exit(1);
		}
	}
	DIR *dirp;
	if((dirp = opendir(startdir)) == NULL) {
		perror("opendir");
		exit(1);
	} 
	
	struct dirent *dp;
	while((dp = readdir(dirp)) != NULL && numkids < MAXWORKERS) {

		if(strcmp(dp->d_name, ".") == 0 || strcmp(dp->d_name, "..") == 0 ||
		   strcmp(dp->d_name, ".svn") == 0) {
			continue;
		}
		strncpy(path, startdir, PATHLENGTH);
		strncat(path, "/", PATHLENGTH - strlen(path) - 1);
		strncat(path, dp->d_name, PATHLENGTH - strlen(path) - 1);
		
		struct stat sbuf;
		if(stat(path, &sbuf) == -1) {
			//This should only fail if we got the path wrong
			// or we don't have permissions on this entry.
			perror("stat");
			exit(1);
		} 

		// Only call run_worker if it is a directory
		// Otherwise ignore it.
		if(!S_ISDIR(sbuf.st_mode)) {
			continue;
		}
		// Found a directory that ought to have an index, so create a worker
		if(pipe(infds[numkids]) == -1){
			perror("pipe");
			exit(1);
		}
		
		if(pipe(outfds[numkids]) == -1){
			perror("pipe");
			exit(1);
		}
		
		pids[numkids] = fork();
		if(pids[numkids] == -1 ) {
			perror("fork");
			exit(1);
		} else if(pids[numkids] > 0) {  // master
			close(infds[numkids][1]);
			close(outfds[numkids][0]);
			numkids++;
			
		} else {
			close(infds[numkids][0]);
			close(outfds[numkids][1]);
			int j;
			// close pipes we don't need
			for(j = 0; j < numkids; j++) {
				close(infds[j][0]);
				close(outfds[j][1]);
			}
			printf("Calling worker where worker reads from %d writes to %d\n",
				outfds[numkids][0], infds[numkids][1]);
			run_worker(path, outfds[numkids][0], infds[numkids][1]);
			exit(0);
		}
		
	}
	
	/* Now that all the processes have started, get a word from standard 	
	* input and write it to all the kids. */
	while (1) {
	printf("Enter a word to search for:\n");  

if (!fgets(line, MAXWORD, stdin)) {
// close pipe-ends
int j;
			for(j = 0; j < numkids; j++) {
				if (close(infds[j][0]) == -1) perror("close");
				if (close(outfds[j][1]) == -1) perror("close");
			}

exit (1);
}


	char *ptr;
	if((ptr= strchr(line, '\n'))) {
		*ptr = '\0';
	}
	for(i = 0; i < numkids; i++){
		if(write(outfds[i][1], line, MAXWORD) != MAXWORD) {
			perror("write");
		}
	}
	
	FreqRecord fqr[MAXRECORDS];
	init_freq_records(fqr);
	for(i = 0; i < numkids; i++ ) {
		FreqRecord f;
		int nread;
		if((nread = read(infds[i][0], &f, sizeof(FreqRecord))) == -1) {
			perror("read");
		} else if(nread == 0) {
			fprintf(stderr, "pipe closed on first read [%d]\n", i);
		}
		while(f.freq != 0) {
			insert_freq_record(fqr, f);
			if((nread = read(infds[i][0], &f, sizeof(FreqRecord))) == -1) {
				perror("read");
			} else if(nread == 0) {
				fprintf(stderr, "pipe closed on subsequent read %d\n", i);
			}
		}
	}
printf("\n*****\n\n");
	print_freq_records(fqr);
	}
	return 0;
}
