#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "worker.h"

int main() {

    char * first_dir = "a3/marking_files/solo_with_sorting/dir1";
//    FILE * fp= fopen("t1.bin", "w");
//    run_worker(first_dir, STDIN_FILENO, fileno(fp) );
    run_worker(first_dir, STDIN_FILENO, STDOUT_FILENO );

//    fclose(fp);
    return 0;
}
