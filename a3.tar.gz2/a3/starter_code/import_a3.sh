course="cscb09w13"

for name in `cat utorids`; do
     svn import --force  -m "Initial import A3" a3 file:///courses/subversion/$course/$name/a3 -m "Initial import A3";
done
